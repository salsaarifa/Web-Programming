<?php include './layout/header.php' ?>
<!-- MAIN CONTENT -->
<main class="py-5">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-12 col-md-6 text-justify">
        <h1 class="fw-bold">Selamat Datang di <br> LOCRENT !</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit consectetur adipisicing elit</p>
        <p>
          Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quod ut et odio eos velit ipsam officiis iste illum, corrupti ducimus, voluptatem commodi aperiam odit enim explicabo tempore. Iure, excepturi amet?
          Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quod ut et odio eos velit ipsam officiis iste illum, corrupti ducimus, voluptatem commodi aperiam odit enim explicabo tempore. Iure, excepturi amet?
        </p>
        <p>
          <a href="#" class="btn btn-outline-primary btn-lg">SELENGKAPNYA</a>
        </p>
      </div>
      <div class="col-12 col-md-6">
        <img src="./assets/img/Mobil jeep.png" alt="" class="img-fluid">
      </div>
    </div>
  </div>
</main>

<?php include './layout/footer.php' ?>